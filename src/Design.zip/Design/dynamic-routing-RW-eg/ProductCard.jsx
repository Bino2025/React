import React from 'react'
import './ProductCard.css'

const ProductCard = ({product}) => {

  return (
    <div className='product-card'>
      {product.offer && <span className='offer-badge'>{product.offer}</span>}
    </div>
  )
}

export default ProductCard
